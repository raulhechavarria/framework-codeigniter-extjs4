/**
 * @class Bleext.modules.catalogs.users.view.UserForm
 * @extends Bleext.abstract.Form
 * requires 
 * @autor Crysfel Villa
 * @date Tue Aug  2 00:49:37 CDT 2011
 *
 * Description
 *
 *
 **/

Ext.define("Bleext.modules.catalogs.users.view.UserForm",{
	extend		: "Bleext.abstract.Form",
	

	initComponent	: function() {
		var me = this;
		
        
		me.callParent();
	}
});