/**
 * @class Bleext.modules.catalogs.roles.view.RoleForm
 * @extends Bleext.abstract.Form
 * requires 
 * @autor Crysfel Villa
 * @date Tue Aug  2 00:56:55 CDT 2011
 *
 * Description
 *
 *
 **/

Ext.define("Bleext.modules.catalogs.roles.view.RoleForm",{
	extend		: "Bleext.abstract.Form",
	

	initComponent	: function() {
		var me = this;
		
        
		me.callParent();
	}
});