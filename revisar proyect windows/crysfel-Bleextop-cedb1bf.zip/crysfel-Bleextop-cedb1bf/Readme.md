<h1>Bleextop</h1>

Bleextop is a Desktop solution for ExtJS4, the main idea is to provide a platform that helps developers to start their own applications. This project works with Ext4 and CodeIgniter.

<h2>Demo</h2>
A demo version is located at: 

http://demos.bleext.com/desktop/

user: crysfel
pass: 123

Please report any issue

<h2>Installing</h2>
<ol>
	<li>Download the project</li>
	<li>Edit the <strong>.htaccess</strong> file that is in the root directory of the project, modify the path  according to your system (Line 4), if you do not have the mod-rewrite in your apache just comment all lines in this file</li>
	<li>Open the <strong>application/config/config.php</strong> file and change the <strong>'base_url'</strong> configuration (Line 17), this is the URL of your project</li>
	<li>Open the <strong>application/config/database.php</strong> file and set your database credentials (Line 44)</li>
	<li>Create a database "<strong>desktop</strong>" in your mysql server. 
	<li>Load the <strong>database/desktop.sql</strong> script in your mysql server</li>
	<li>With your favorite browser go to the url where your project is.</li>
</ol>
