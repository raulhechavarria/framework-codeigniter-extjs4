{
	"success"	: false,
	"code"		: 500,
	"message"	: "Sorry for the inconvenience but there was a system error",
	"info"	: 'A PHP Error was encountered
		* Severity: <?php echo $severity; ?>
		* Message:  <?php echo $message; ?>
		* Filename: <?php echo $filepath; ?>
		* Line Number: <?php echo $line; ?>'
}