<?php

class BleextBI{
	
	function BleextBI(){
		$this->instance =& get_instance();
	}
	
}